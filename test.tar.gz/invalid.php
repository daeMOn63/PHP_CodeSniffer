<?php

echo 'foo';