<?php

class MyStandard_Sniffs_PreCheck_SkipTemplateSniff extends PHP_CodeSniffer_PreSniff {

    public function register() {
        return array(T_OPEN_TAG);
    }

    public function check(PHP_CodeSniffer_File $phpcsFile, $stackPtr) {
        $tokens = $phpcsFile->getTokens();

        if ($phpcsFile->findNext(T_INLINE_HTML, $stackPtr + 1) !== false) {
            echo 'Skipping file : '.$phpcsFile->getFilename() . "\n";
            return false;
        } else {
            echo 'File : '.$phpcsFile->getFilename() . ' passed ' .get_class($this). " validation\n";
            return true;
        }
    }
}