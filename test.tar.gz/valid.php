<?php

echo 'foo';
