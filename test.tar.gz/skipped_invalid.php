<?php

echo 'foo';

?>
<some><html><tag>
<?php

echo 'foo';